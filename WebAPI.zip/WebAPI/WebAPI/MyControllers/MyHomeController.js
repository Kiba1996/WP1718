﻿WebAPI.controller('MyHomeController', function ($scope, $rootScope, LogCont, $window) {

  
    function init() {
       

    }

    init();

});