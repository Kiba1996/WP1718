﻿using project.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebAPI.DataIO;
using WebAPI.MyHelpers;

namespace WebAPI.Controllers
{
    public class ProfController : ApiController
    {
        public static XMLDataIO xml = new XMLDataIO();

        [HttpGet]
        [ActionName("GetUserByUsername")]
        public User GetUserByUsername(string username)
        {
            string ss = System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/Users.xml");
            List<User> users = xml.ReadUsers(ss);

            foreach(User us in users) { 
                if (us.UserName == username)
                {
                    User kor = new Customer();
                    kor.UserName = us.UserName;
                    kor.Name = us.Name;
                    kor.Surname = us.Surname;
                    kor.Role = us.Role;
                    kor.Email = us.Email;
                    kor.ContactPhoneNumber = us.ContactPhoneNumber;
                    kor.Gender =us.Gender;
                    kor.Password = null;
                    kor.JMBG = us.JMBG;
                    kor.Drives = us.Drives;
                    
                    return kor;
                }
            }
           
            return null;
        }

        [HttpPost]
        [ActionName("AddDriveCustomer")]
        public bool Register([FromBody]DriveR k)
        {
            string ss = System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/Users.xml");
            string ss1 = System.Web.Hosting.HostingEnvironment.MapPath("~/App_Data/Drives.xml");

            List<User> users = xml.ReadUsers(ss);
            List<Drive> drives = xml.ReadDrives(ss1);
           // bool g = true;
            User c = new Customer();
            Drive drive = new Drive();
            foreach (User u in users)
            {
                if (u.UserName == k.korisnicko)
                {
                    c = u;
                    Address a = new Address(k.Street, k.Number, k.Town, Int32.Parse(k.PostalCode));
                    Location l = new Location(k.XCoord, k.YCoord, a);
                    drive.Customer = (Customer)c;
                    drive.Arrival = l;
                    if (k.tipAuta != "")
                    {
                        drive.CarType = (Enums.CarType)int.Parse(k.tipAuta);
                    }
                    drive.Amount = 0;
                    drive.Comment = null;
                    drive.DataAndTime = DateTime.Now;
                    drive.Destination = null;
                    drive.Dispatcher = null;
                    drive.Driver = null;
                    drive.Status = Enums.DriveStatus.Created_Waiting;
                   // u.Drives.Add(drive);

                    //  g = false;
                }
            }
            
               drives.Add(drive);
               xml.WriteUsers(users, ss);
               xml.WriteDrives(drives, ss1);

                return true;
           

        }

    }
}
