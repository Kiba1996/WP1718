﻿using project.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
namespace WebAPI.DataIO
{
    public class XMLDataIO
    {
        public List<User> ReadUsers(string fileName)
        {
            XmlSerializer desrializer = new XmlSerializer(typeof(List<User>));
            List<User> retVal = new List<User>();
            if (File.Exists(fileName)){
                using (TextReader reader = new StreamReader(fileName))
                {
                    object obj = desrializer.Deserialize(reader);
                    retVal = (List<User>)obj;
                }
            }
            return retVal;
        }

        public void WriteUsers(List<User> users, string fileName)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<User>));
            using (TextWriter write = new StreamWriter(fileName))
            {
                xml.Serialize(write, users);
            }
        }

        public List<Drive> ReadDrives(string fileName)
        {
            XmlSerializer desrializer = new XmlSerializer(typeof(List<Drive>));
            List<Drive> retVal = new List<Drive>();
            if (File.Exists(fileName))
            {
                using (TextReader reader = new StreamReader(fileName))
                {
                    object obj = desrializer.Deserialize(reader);
                    retVal = (List<Drive>)obj;
                }
            }
            return retVal;
        }

        public void WriteDrives(List<Drive> drives, string fileName)
        {
            XmlSerializer xml = new XmlSerializer(typeof(List<Drive>));
            using (TextWriter write = new StreamWriter(fileName))
            {
                xml.Serialize(write, drives);
            }
        }

    }
}